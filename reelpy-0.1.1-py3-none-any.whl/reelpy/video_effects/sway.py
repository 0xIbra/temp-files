from moviepy.editor import ImageSequenceClip, AudioFileClip, CompositeAudioClip, VideoFileClip
from PIL import Image
from uuid import uuid4
import numpy as np
import cv2
import os


def sway(
    input_path: str,
    output_video: str,
    duration: float = None,
    audio_path: str = None,
    fps: int = 30,
    start_time: float = 0,
    end_time: float = None,
    sound_effect_path: str = None,
    sound_effect_start: float = 0,
    sound_effect_end: float = None,
    audio_volume: float = 1.0,
    sound_effect_volume: float = 1.0,
    sway_angle: float = 1.5,
    sway_speed: float = 1.5,
    move_amplitude: float = 15.0,
    move_speed_x: float = 1.0,
    move_speed_y: float = 1.0
) -> str:
    """
    Apply a sway effect to an image or video and create a video with optional audio.

    :param input_path: Path to the input image or video
    :param output_video: Path for the output video
    :param duration: Duration of the video in seconds (required if no audio_path and input is image)
    :param audio_path: Optional path to the audio file
    :param fps: Frames per second for the video
    :param start_time: Start time of the sway effect in seconds
    :param end_time: End time of the sway effect in seconds
    :param sound_effect_path: Path to the sound effect file
    :param sound_effect_start: Start time of the sound effect in seconds
    :param sound_effect_end: End time of the sound effect in seconds
    :param audio_volume: Volume of the main audio
    :param sound_effect_volume: Volume of the sound effect
    :param sway_angle: Maximum sway angle for the image (degrees)
    :param sway_speed: Speed of the sway effect
    :param move_amplitude: Amplitude for x, y movement in pixels
    :param move_speed_x: Speed of the x-axis movement
    :param move_speed_y: Speed of the y-axis movement
    :return: Path to the output video file
    """
    # Determine if input is video or image
    is_video = os.path.splitext(input_path)[1].lower() in ['.mp4', '.avi', '.mov', '.mkv']

    if is_video:
        video_clip = VideoFileClip(input_path)
        image_np = video_clip.get_frame(0)  # Get first frame for dimensions
        total_duration = video_clip.duration
        if audio_path is None:
            audio_clip = video_clip.audio
        fps = video_clip.fps if fps is None else fps
    else:
        # Image input
        if duration is None and audio_path is None:
            raise ValueError("Either duration or audio_path must be provided for image input")
        image = Image.open(input_path)
        image_np = np.array(image)
        video_clip = None

    # Image dimensions
    h, w = image_np.shape[:2]

    # Calculate zoom factors
    max_angle_rad = np.radians(sway_angle)
    zoom_factor = 1 / np.cos(max_angle_rad)
    move_zoom_x = (move_amplitude * 2) / w
    move_zoom_y = (move_amplitude * 2) / h
    zoom_factor += max(move_zoom_x, move_zoom_y)

    def transform_frame(frame, angle, tx, ty):
        """Apply zoom, rotation and translation to a frame."""
        # Apply zoom
        zoomed_width = int(w * zoom_factor)
        zoomed_height = int(h * zoom_factor)
        zoomed_frame = cv2.resize(frame, (zoomed_width, zoomed_height), interpolation=cv2.INTER_LINEAR)

        # Crop to original size from center
        crop_x = (zoomed_width - w) // 2
        crop_y = (zoomed_height - h) // 2
        zoomed_frame = zoomed_frame[crop_y:crop_y + h, crop_x:crop_x + w]

        # Rotation
        M_rotate = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
        rotated = cv2.warpAffine(zoomed_frame, M_rotate, (w, h), borderMode=cv2.BORDER_REPLICATE)
        # Translation
        M_translate = np.float32([[1, 0, tx], [0, 1, ty]])
        transformed = cv2.warpAffine(rotated, M_translate, (w, h), borderMode=cv2.BORDER_REPLICATE)
        return transformed

    # Determine video duration and prepare audio
    if audio_path:
        audio_clip = AudioFileClip(audio_path).volumex(audio_volume)
        total_duration = audio_clip.duration
    elif not is_video:
        total_duration = duration

    # Calculate frames and timing
    total_frames = int(fps * total_duration)
    if end_time is None or end_time > total_duration:
        end_time = total_duration
    start_frame = int(start_time * fps)
    end_frame = int(end_time * fps)

    def make_frame(t):
        frame_number = int(t * fps)

        if is_video:
            current_frame = video_clip.get_frame(t)
        else:
            current_frame = image_np

        if start_frame <= frame_number <= end_frame:
            progress = t / total_duration
            angle = sway_angle * np.sin(2 * np.pi * sway_speed * progress)
            tx = move_amplitude * np.sin(2 * np.pi * move_speed_x * progress)
            ty = move_amplitude * np.cos(2 * np.pi * move_speed_y * progress)
            return transform_frame(current_frame, angle, tx, ty)
        return current_frame

    # Create video clip
    if is_video:
        clip = VideoFileClip(input_path)
        clip = clip.fl_image(lambda img: make_frame(clip.reader.pos/clip.fps))
        clip = clip.set_duration(total_duration)
    else:
        frames = [make_frame(t) for t in np.arange(0, total_duration, 1/fps)]
        clip = ImageSequenceClip(frames, fps=fps)

    # Handle audio
    if (audio_path and audio_clip) or sound_effect_path:
        if sound_effect_path:
            sound_effect_clip = AudioFileClip(sound_effect_path).volumex(sound_effect_volume)
            if sound_effect_end is None or sound_effect_end > total_duration:
                sound_effect_end = total_duration
            sound_effect_clip = sound_effect_clip.subclip(0, sound_effect_end - sound_effect_start)
            sound_effect_clip = sound_effect_clip.set_start(sound_effect_start)

            if audio_clip:
                final_audio = CompositeAudioClip([audio_clip, sound_effect_clip])
            else:
                final_audio = sound_effect_clip
        else:
            final_audio = audio_clip

        clip = clip.set_audio(final_audio)

    # Write final video
    clip.write_videofile(
        output_video,
        codec="libx264",
        audio_codec="aac",
        temp_audiofile=f"/tmp/temp_audio_sway_{str(uuid4())}.mp4",
    )

    # Clean up
    if is_video:
        video_clip.close()
    if audio_path and audio_clip:
        audio_clip.close()

    return output_video
