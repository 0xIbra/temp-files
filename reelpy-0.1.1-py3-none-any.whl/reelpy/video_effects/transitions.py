from moviepy.editor import VideoFileClip, CompositeVideoClip
# import numpy as np

# def crossfade(clip1: VideoFileClip, clip2: VideoFileClip, duration: float) -> VideoFileClip:
#     """Create a crossfade transition between two clips."""
#     def transition_mask(t):
#         return t / duration

#     clip1 = clip1.set_end(clip1.end - duration/2)
#     clip2 = clip2.set_start(clip2.start + duration/2)

#     return CompositeVideoClip([
#         clip1,
#         clip2.set_start(clip1.end - duration).crossfadein(duration)
#     ])

def fade_in(clip: VideoFileClip, duration: float) -> VideoFileClip:
    """Apply fade in effect to a clip."""
    return clip.fadein(duration)

def fade_out(clip: VideoFileClip, duration: float) -> VideoFileClip:
    """Apply fade out effect to a clip."""
    return clip.fadeout(duration)