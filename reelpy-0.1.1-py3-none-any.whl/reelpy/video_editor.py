from typing import List, Optional, Union
import os

from moviepy.editor import (
    AudioFileClip,
    CompositeVideoClip,
    CompositeAudioClip,
    TextClip,
    VideoFileClip,
)
from pydub import AudioSegment

from .video_effects import (
    pan_right,
    pan_left,
    sway,
    glitch,
    camera_shake,
    zoom_in,
    zoom_out,
)
from .video_effects.transitions import fade_in, fade_out


class TimelineProcessor:
    def __init__(self, timeline_data: dict):
        """Initialize timeline processor with JSON string."""
        self.timeline = timeline_data
        self.metadata = self.timeline["metadata"]
        self.width = self.metadata["resolution"]["width"]
        self.height = self.metadata["resolution"]["height"]
        self.fps = self.metadata["fps"]
        self.duration = self.metadata.get("duration", 0)

        # Temp directory for processing
        self.temp_dir = "/tmp/timeline_processing"
        os.makedirs(self.temp_dir, exist_ok=True)

    def _validate_source_files(self):
        """Validate all source files exist."""
        for track in self.timeline["visual_tracks"]:
            for element in track["elements"]:
                source_path = self._get_source_path(element["source"])
                if not source_path:
                    raise ValueError(f"Invalid source for element {element['id']}")
                if not os.path.exists(source_path):
                    raise FileNotFoundError(f"Source file not found: {source_path}")

    def _get_source_path(self, source: Union[str, dict]) -> Optional[str]:
        """Extract source path from source definition."""
        if isinstance(source, str):
            return source
        elif isinstance(source, dict):
            if source["type"] == "path":
                return source["value"]
            elif source["type"] == "generation":
                # TODO: Implement AI image generation
                # This should handle generation params like:
                # - model
                # - style
                # - aspect_ratio
                # - prompt
                raise NotImplementedError("AI image generation not yet implemented")
        return None

    def apply_effect(self, element: dict, input_path: str) -> str:
        """Apply visual effects to an element."""
        if "effects" not in element:
            return input_path

        output_path = input_path
        for effect in element["effects"]:
            effect_type = effect["type"]
            params = effect.get("params", {})

            scene_start = effect.get("start_time", element["start_time"])
            scene_end = effect.get("end_time", element["end_time"])
            # INFO: if input is video, duration param does not matter, the duration of the video will be used.
            duration = scene_end - scene_start
            params["duration"] = duration

            if "start_time" in params:
                params["start_time"] = params["start_time"] - element["start_time"]
            if "end_time" in params:
                params["end_time"] = params["end_time"] - element["start_time"]

            if effect_type == "glitch":
                # rename start_time -> start_glitch and end_time -> end_glitch
                if "start_time" in params:
                    params["start_glitch"] = params["start_time"]
                    del params["start_time"]
                if "end_time" in params:
                    params["end_glitch"] = params["end_time"]
                    del params["end_time"]

                params["start_glitch"] = params["start_glitch"] - element["start_time"]
                params["end_glitch"] = params["end_glitch"] - element["start_time"]

            # Ensure temp output has .mp4 extension for video files
            base_name = os.path.splitext(os.path.basename(output_path))[0]
            temp_output = f"{self.temp_dir}/effect_{base_name}.mp4"

            # Handle image effects
            if element["type"] == "image":
                if effect_type == "zoom_in":
                    output_path = zoom_in(
                        input_path=output_path,
                        output_video=temp_output,
                        **params
                    )
                elif effect_type == "zoom_out":
                    output_path = zoom_out(
                        input_path=output_path,
                        output_video=temp_output,
                        **params
                    )
                elif effect_type == "pan_right":
                    output_path = pan_right(
                        input_path=output_path,
                        output_video=temp_output,
                        output_width=params.get("output_width", self.width),
                        **params
                    )
                elif effect_type == "pan_left":
                    output_path = pan_left(
                        input_path=output_path,
                        output_video=temp_output,
                        output_width=params.get("output_width", self.width),
                        **params
                    )
                elif effect_type == "sway":
                    output_path = sway(
                        input_path=output_path,
                        output_video=temp_output,
                        **params
                    )
                elif effect_type == "shake":
                    output_path = camera_shake(
                        input_path=output_path,
                        output_video=temp_output,
                        **params
                    )
                elif effect_type == "glitch":
                    output_path = glitch(
                        input_path=output_path,
                        output_video=temp_output,
                        **params
                    )

        return output_path

    def process_visual_element(self, element: dict) -> VideoFileClip:
        """Process a single visual element (image, video, or text)."""
        # Get source path
        source_path = self._get_source_path(element["source"])
        if not source_path:
            raise ValueError(f"Invalid source for element {element['id']}")

        # Apply effects and create clip based on type
        if element["type"] in ["image", "video"]:
            processed_path = self.apply_effect(element, source_path)
            clip = VideoFileClip(processed_path)
        elif element["type"] == "text":
            clip = TextClip(
                element["source"],
                fontsize=element["font_size"],
                color=element["font_color"],
                bg_color=element.get("font_bg_color"),
                size=(self.width, None)
            )
            if isinstance(element["position"], str):
                clip = clip.set_position(element["position"])
            else:
                clip = clip.set_position((element["position"]["x"], element["position"]["y"]))

        # Set timing
        return clip.set_start(element["start_time"]).set_end(element["end_time"])

    def process_audio_element(self, element: dict, track_dbfs: float) -> AudioFileClip:
        source_path = self._get_source_path(element["source"])
        if not source_path:
            raise ValueError(f"Invalid source for audio element {element['id']}")

        # Load audio
        audio = AudioSegment.from_file(source_path)

        # Calculate gain more conservatively
        current_dbfs = audio.dBFS
        target_dbfs = element.get("dbfs_gain", track_dbfs)
        max_gain_adjustment = 20  # dB
        gain_needed = max(min(target_dbfs - current_dbfs, max_gain_adjustment), -max_gain_adjustment)
        normalized_audio = audio.apply_gain(gain_needed)

        # Handle special {end} keyword for end_time
        if element["end_time"] in ["{end}", "{END}"]:
            element["end_time"] = element["start_time"] + (len(audio) / 1000.0)  # Convert ms to seconds

        # Handle looping if specified
        if element.get("loop", False):
            target_duration = (element["end_time"] - element["start_time"]) * 1000
            while len(normalized_audio) < target_duration:
                normalized_audio += normalized_audio
            normalized_audio = normalized_audio[:int(target_duration)]

        # Export normalized audio
        temp_path = f"{self.temp_dir}/normalized_{os.path.basename(source_path)}"
        normalized_audio.export(temp_path, format="mp3")

        clip = AudioFileClip(temp_path)
        clip = clip.set_start(element["start_time"]).set_end(element["end_time"])
        return clip

    def process_transitions(self, clips: List[VideoFileClip]) -> List[VideoFileClip]:
        """Process transitions between clips."""
        if not clips:
            return clips

        processed_clips = [clips[0]]

        for i in range(1, len(clips)):
            current_clip = clips[i]
            prev_clip = processed_clips[-1]

            # Get transition from previous clip's transition_out
            prev_element = self.timeline["visual_tracks"][0]["elements"][i-1]
            transition = prev_element.get("transition_out")

            if transition:
                if transition["type"] == "fade":
                    duration = transition.get("duration", 0.5)
                    processed_clips[-1] = fade_out(prev_clip, duration)
                    current_clip = fade_in(current_clip, duration)

            processed_clips.append(current_clip)

        return processed_clips

    def render(self, output_path: str):
        """Process the timeline and render the final video."""
        try:
            # Process visual tracks in z-index order
            visual_clips = []
            for track in sorted(self.timeline["visual_tracks"], key=lambda x: x["z-index"]):
                for element in track["elements"]:
                    clip = self.process_visual_element(element)
                    visual_clips.append(clip)

            # Process transitions
            visual_clips = self.process_transitions(visual_clips)

            # Create base composite video
            final_video = CompositeVideoClip(visual_clips, size=(self.width, self.height))

            # Process audio tracks
            audio_clips = []
            for track in self.timeline["audio_tracks"]:
                track_dbfs = track["dbfs_gain"]
                for element in track["elements"]:
                    audio_clip = self.process_audio_element(element, track_dbfs)
                    audio_clips.append(audio_clip)

            # Combine all audio if present
            if audio_clips:
                final_audio = CompositeAudioClip(audio_clips)
                final_video = final_video.set_audio(final_audio)

            # Write final video
            final_video.write_videofile(
                output_path,
                fps=self.fps,
                codec="libx264",
                audio_codec="aac",
                temp_audiofile=f"{self.temp_dir}/temp_audio.m4a",
                remove_temp=True
            )

        finally:
            # Cleanup temp files
            if os.path.exists(self.temp_dir):
                for file in os.listdir(self.temp_dir):
                    try:
                        os.remove(os.path.join(self.temp_dir, file))
                    except:
                        pass
                os.rmdir(self.temp_dir)
