from moviepy.editor import VideoFileClip, AudioFileClip, CompositeAudioClip, ImageSequenceClip
from typing import Tuple
from uuid import uuid4
import numpy as np
import random
import cv2
import os


def create_channel_shift(image: np.ndarray, shift_x: int, shift_y: int, channel: int) -> np.ndarray:
    """Apply RGB channel shift to create chromatic aberration effect."""
    result = image.copy()
    height, width = image.shape[:2]

    # Create the shift matrix
    M = np.float32([[1, 0, shift_x], [0, 1, shift_y]])
    shifted = cv2.warpAffine(image[:, :, channel], M, (width, height))

    result[:, :, channel] = shifted
    return result


def apply_scanlines(image: np.ndarray, intensity: float = 0.3) -> np.ndarray:
    """Apply scanline effect with variable intensity."""
    result = image.astype(np.float32)  # Convert to float32 for calculations
    height = image.shape[0]

    # Create scanlines pattern
    scanlines = np.ones_like(result)
    for y in range(0, height, 2):
        scanlines[y, :] *= (1 - intensity)

    # Apply scanlines and ensure values stay within valid range
    result = result * scanlines
    result = np.clip(result, 0, 255)  # Ensure values stay in valid range

    return result.astype(np.uint8)  # Convert back to uint8 for image


def apply_enhanced_glitch(
    image_path: str,
    seed: int = None,
    min_amount: int = 1,
    max_amount: int = 10,
    intensity: float = 0.5
) -> Tuple[str, np.ndarray]:
    """Apply an enhanced glitch effect with color channel splitting and scanlines."""
    prng = random.Random(seed)

    # Read the image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Unable to load image from {image_path}")

    height, width = image.shape[:2]
    result = image.copy()

    # Apply random transformations
    num_glitches = prng.randint(min_amount, max_amount)

    for _ in range(num_glitches):
        # Random slice parameters
        slice_height = prng.randint(10, height // 4)
        y_start = prng.randint(0, height - slice_height)

        # Vertical slice displacement
        slice_shift = prng.randint(-width // 6, width // 6)

        if slice_shift != 0:
            slice_region = result[y_start:y_start + slice_height, :]
            if slice_shift > 0:
                slice_region = np.hstack([slice_region[:, -slice_shift:], slice_region[:, :-slice_shift]])
            else:
                slice_region = np.hstack([slice_region[:, abs(slice_shift):], slice_region[:, :abs(slice_shift)]])
            result[y_start:y_start + slice_height, :] = slice_region

        # Color channel splitting
        if prng.random() < intensity:
            channel = prng.randint(0, 2)  # Choose random color channel
            shift_x = prng.randint(-15, 15)
            shift_y = prng.randint(-5, 5)
            result = create_channel_shift(result, shift_x, shift_y, channel)

    # Add chromatic aberration
    if prng.random() < intensity:
        result = create_channel_shift(result, 4, 0, 0)  # Red channel
        result = create_channel_shift(result, -4, 0, 2)  # Blue channel

    # Apply scanlines (with reduced intensity to avoid overpowering the effect)
    result = apply_scanlines(result, intensity * 0.3)

    # Save the result
    output_path = f"/tmp/enhanced_glitched_{os.path.basename(image_path)}"
    cv2.imwrite(output_path, result)

    return output_path, result


def glitch(
    input_path: str,
    output_video: str,
    duration: float = None,
    audio_path: str | None = None,
    start_glitch: float = 0,
    end_glitch: float | None = None,
    fps: int = 30,
    glitch_intensity: float = 0.3,
    audio_volume: float = 1.0,
    sound_effect_path: str | None = None,
    sound_effect_start: float = 0,
    sound_effect_end: float | None = None,
    sound_effect_volume: float = 1.0
) -> str:
    """
    Create a video with a glitch effect from an image or video input.

    Args:
        input_path: Path to the input image or video
        output_video: Path for the output video
        duration: Duration in seconds (required for images if no audio_path)
        audio_path: Optional path to the audio file (for image input only)
        start_glitch: Start time of the glitch effect in seconds
        end_glitch: End time of the glitch effect in seconds
        fps: Frames per second for the video
        glitch_intensity: Intensity of the glitch effect
        audio_volume: Volume of the main audio (if provided)
        sound_effect_path: Optional path to the sound effect file
        sound_effect_start: Start time of the sound effect in seconds
        sound_effect_end: End time of the sound effect in seconds
        sound_effect_volume: Volume of the sound effect
    """
    # Determine if input is video or image based on file extension
    is_video = input_path.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.webm'))

    if is_video:
        # Load input video
        video = VideoFileClip(input_path)
        fps = fps or video.fps
        total_duration = duration if duration is not None else video.duration
        main_audio = video.audio
    else:
        # Handle image input
        if duration is None and audio_path is None:
            raise ValueError("Either duration or audio_path must be provided for image input")

        # Load image
        img = cv2.imread(input_path)
        if img is None:
            raise ValueError(f"Unable to load image from {input_path}")

        if audio_path:
            audio_clip = AudioFileClip(audio_path).volumex(audio_volume)
            total_duration = audio_clip.duration
            main_audio = audio_clip
        else:
            total_duration = duration
            main_audio = None

    if end_glitch is None or end_glitch > total_duration:
        end_glitch = total_duration

    if is_video:
        def apply_glitch_frame(get_frame, t):
            frame = get_frame(t)
            if start_glitch <= t <= end_glitch:
                temp_frame_path = f"/tmp/temp_frame_{int(t*1000)}.jpg"
                cv2.imwrite(temp_frame_path, cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))

                glitched_frame_path, _ = apply_enhanced_glitch(
                    temp_frame_path,
                    seed=int(t * fps),
                    min_amount=int(glitch_intensity * 10),
                    max_amount=int(glitch_intensity * 20),
                    intensity=glitch_intensity
                )

                # Read the glitched frame and convert back to RGB
                glitched_frame = cv2.imread(glitched_frame_path)
                glitched_frame = cv2.cvtColor(glitched_frame, cv2.COLOR_BGR2RGB)

                # Clean up temporary files
                os.remove(temp_frame_path)
                os.remove(glitched_frame_path)

                return glitched_frame
            return frame

        final_clip = video.fl(apply_glitch_frame)

    else:
        # Create temporary video file for image input
        height, width = img.shape[:2]
        frames = []

        # Generate frames with glitch effect
        for t in range(int(total_duration * fps)):
            current_time = t / fps
            if start_glitch <= current_time <= end_glitch:
                glitched_image_path, _ = apply_enhanced_glitch(
                    input_path,
                    seed=t,
                    min_amount=int(glitch_intensity * 10),
                    max_amount=int(glitch_intensity * 20),
                    intensity=glitch_intensity
                )
                glitched_frame = cv2.imread(glitched_image_path)
                os.remove(glitched_image_path)
            else:
                glitched_frame = img.copy()

            # Convert BGR to RGB for MoviePy
            glitched_frame = cv2.cvtColor(glitched_frame, cv2.COLOR_BGR2RGB)
            frames.append(glitched_frame)

        final_clip = ImageSequenceClip(frames, fps=fps)

    # Handle audio
    if sound_effect_path:
        sfx_clip = AudioFileClip(sound_effect_path).volumex(sound_effect_volume)
        if sound_effect_end is None or sound_effect_end > total_duration:
            sound_effect_end = total_duration
        sfx_clip = sfx_clip.subclip(0, sound_effect_end - sound_effect_start)
        sfx_clip = sfx_clip.set_start(sound_effect_start)

        if main_audio:
            final_audio = CompositeAudioClip([main_audio, sfx_clip])
        else:
            final_audio = sfx_clip

        final_clip = final_clip.set_audio(final_audio)
    elif main_audio:
        final_clip = final_clip.set_audio(main_audio)

    # Write the final video
    final_clip.write_videofile(
        output_video,
        codec="libx264",
        audio_codec="aac",
        temp_audiofile=f"/tmp/temp_audio_glitch_{str(uuid4())}.mp4"
    )

    return output_video
