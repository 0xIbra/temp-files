from moviepy.editor import AudioFileClip, CompositeAudioClip, ImageSequenceClip, VideoFileClip
from PIL import Image
from uuid import uuid4
import numpy as np
import os


def pan_right(
    input_path: str,
    output_video: str,
    output_width: int,
    duration: float = None,
    audio_path: str = None,
    fps: int = 60,
    audio_volume: float = 1.0,
    sound_effect_path: str = None,
    sound_effect_start: float = 0.0,
    sound_effect_end: float = None,
    sound_effect_volume: float = 1.0,
    pan_duration_ratio: float = 0.98,
) -> str:
    """
    Apply the pan right effect to an image or video and return the video clip.

    :param input_path: Path to the input image or video file
    :param output_video: Path to the output video file
    :param output_width: Width of the output video
    :param duration: Duration of the video in seconds (required if no audio_path)
    :param audio_path: Optional path to the audio file
    :param fps: Frames per second for the output video
    :param audio_volume: Volume of the main audio
    :param sound_effect_path: Path to the sound effect file
    :param sound_effect_start: Start time of the sound effect
    :param sound_effect_end: End time of the sound effect
    :param sound_effect_volume: Volume of the sound effect
    :param pan_duration_ratio: Ratio of total duration for panning effect (default: 0.98)
    :return: Path to the output video file
    """
    if audio_path is None and duration is None:
        raise ValueError("Either audio_path or duration must be provided")

    # Determine if input is video or image
    is_video = input_path.lower().endswith(('.mp4', '.avi', '.mov', '.mkv'))

    if is_video:
        input_clip = VideoFileClip(input_path)
        input_width = input_clip.w
        input_height = input_clip.h
        if duration is None and audio_path is None:
            duration = input_clip.duration
    else:
        img = Image.open(input_path)
        input_width = img.width
        input_height = img.height

    output_height = input_height
    if output_width > input_width:
        raise ValueError(f"Output width ({output_width}) cannot be larger than the input width ({input_width})")

    # Determine video duration
    if audio_path:
        audio_clip = AudioFileClip(audio_path).volumex(audio_volume)
        total_duration = audio_clip.duration
    else:
        total_duration = duration
        audio_clip = None

    # Calculate panning parameters
    pan_duration = total_duration * pan_duration_ratio
    total_frames = int(pan_duration * fps)
    step_size = (input_width - output_width) / total_frames

    # Create frames by moving the crop window
    frames = []
    for i in range(total_frames):
        left = int(i * step_size)
        if is_video:
            t = (i / fps) % input_clip.duration  # Loop video if needed
            frame = input_clip.get_frame(t)
            frames.append(frame[:, left:left + output_width])
        else:
            box = (left, 0, left + output_width, output_height)
            cropped_img = img.crop(box)
            frames.append(np.array(cropped_img))

    # Add the last frame to fill the remaining duration
    last_frame = frames[-1]
    remaining_frames = int((total_duration - pan_duration) * fps)
    frames.extend([last_frame] * remaining_frames)

    # Create video clip and handle audio
    video_clip = ImageSequenceClip(frames, fps=fps)

    if audio_clip:
        if sound_effect_path:
            sound_effect_clip = AudioFileClip(sound_effect_path).volumex(sound_effect_volume)
            if sound_effect_end is None or sound_effect_end > total_duration:
                sound_effect_end = total_duration
            sound_effect_clip = sound_effect_clip.subclip(0, sound_effect_end - sound_effect_start)
            sound_effect_clip = sound_effect_clip.set_start(sound_effect_start)
            audio_clip = CompositeAudioClip([audio_clip, sound_effect_clip])
        final_clip = video_clip.set_audio(audio_clip)
    else:
        final_clip = video_clip

    # Clean up input video if used
    if is_video:
        input_clip.close()

    final_clip = final_clip.set_duration(total_duration)
    final_clip.write_videofile(
        output_video,
        codec="libx264",
        audio_codec="aac",
        temp_audiofile=f"/tmp/temp_audio_pan_right_{str(uuid4())}.mp4",
    )

    if not os.path.exists(output_video):
        raise FileNotFoundError(f"Output video file {output_video} not found!")

    return output_video


def pan_left(
    input_path: str,
    output_video: str,
    output_width: int,
    duration: float = None,
    audio_path: str = None,
    fps: int = 60,
    audio_volume: float = 1.0,
    sound_effect_path: str = None,
    sound_effect_start: float = 0.0,
    sound_effect_end: float = None,
    sound_effect_volume: float = 1.0,
    pan_duration_ratio: float = 0.98,
) -> str:
    """
    Create a video with a pan left effect from an image or video.

    :param input_path: Path to the input image or video file
    :param output_video: Path for the output video
    :param output_width: Width of the output video
    :param duration: Duration of the video in seconds (required if no audio_path)
    :param audio_path: Optional path to the audio file
    :param fps: Frames per second for the video
    :param audio_volume: Volume of the main audio
    :param sound_effect_path: Path to the sound effect file
    :param sound_effect_start: Start time of the sound effect
    :param sound_effect_end: End time of the sound effect
    :param sound_effect_volume: Volume of the sound effect
    :param pan_duration_ratio: Ratio of total duration for panning effect (default: 0.98)
    :return: Path to the output video file
    """
    if audio_path is None and duration is None:
        raise ValueError("Either audio_path or duration must be provided")

    # Determine if input is video or image
    is_video = input_path.lower().endswith(('.mp4', '.avi', '.mov', '.mkv'))

    if is_video:
        input_clip = VideoFileClip(input_path)
        input_width = input_clip.w
        input_height = input_clip.h
        if duration is None and audio_path is None:
            duration = input_clip.duration
    else:
        img = Image.open(input_path)
        input_width = img.width
        input_height = img.height

    output_height = input_height
    if output_width > input_width:
        raise ValueError(f"Output width ({output_width}) cannot be larger than the input width ({input_width})")

    # Determine video duration
    if audio_path:
        audio_clip = AudioFileClip(audio_path).volumex(audio_volume)
        total_duration = audio_clip.duration
    else:
        total_duration = duration
        audio_clip = None

    # Calculate panning parameters
    pan_duration = total_duration * pan_duration_ratio
    total_frames = int(pan_duration * fps)
    step_size = (input_width - output_width) / total_frames

    # Create frames by moving the crop window from right to left
    frames = []
    for i in range(total_frames):
        right = int(input_width - output_width - (i * step_size))
        if is_video:
            t = (i / fps) % input_clip.duration  # Loop video if needed
            frame = input_clip.get_frame(t)
            frames.append(frame[:, right:right + output_width])
        else:
            box = (right, 0, right + output_width, output_height)
            cropped_img = img.crop(box)
            frames.append(np.array(cropped_img))

    # Add the last frame to fill the remaining duration
    last_frame = frames[-1]
    remaining_frames = int((total_duration - pan_duration) * fps)
    frames.extend([last_frame] * remaining_frames)

    # Create video clip and handle audio
    video_clip = ImageSequenceClip(frames, fps=fps)

    if audio_clip:
        if sound_effect_path:
            sound_effect_clip = AudioFileClip(sound_effect_path).volumex(sound_effect_volume)
            if sound_effect_end is None or sound_effect_end > total_duration:
                sound_effect_end = total_duration
            sound_effect_clip = sound_effect_clip.subclip(0, sound_effect_end - sound_effect_start)
            sound_effect_clip = sound_effect_clip.set_start(sound_effect_start)
            audio_clip = CompositeAudioClip([audio_clip, sound_effect_clip])
        final_clip = video_clip.set_audio(audio_clip)
    else:
        final_clip = video_clip

    # Clean up input video if used
    if is_video:
        input_clip.close()

    final_clip = final_clip.set_duration(total_duration)
    final_clip.write_videofile(
        output_video,
        codec="libx264",
        audio_codec="aac",
        temp_audiofile=f"/tmp/temp_audio_pan_left_{str(uuid4())}.mp4",
    )

    if not os.path.exists(output_video):
        raise FileNotFoundError(f"Output video file {output_video} not found!")

    return output_video
