from moviepy.editor import (
    AudioFileClip,
    CompositeAudioClip,
    VideoClip,
    VideoFileClip,
    ImageClip
)
from typing import Literal
from uuid import uuid4
import numpy as np
import cv2
import os


def zoom_in(
    input_path: str,
    output_video: str,
    duration: float = None,
    audio_path: str = None,
    output_width: int | None = None,
    output_height: int | None = None,
    zoom_factor: float = 1.2,
    fps: int = 30,
    audio_volume: float = 1.0,
    sound_effect_path: str = None,
    sound_effect_start: float = 0.0,
    sound_effect_end: float = None,
    sound_effect_volume: float = 1.0,
    zoom_to: Literal["top", "bottom", "center"] = "center"
) -> str:
    """
    Apply a smooth zoom in effect towards the specified direction for image or video.

    :param input_path: Path to the input image or video
    :param output_video: Path for the output video
    :param duration: Duration of the video in seconds (required if no audio_path and input is image)
    :param audio_path: Optional path to the audio file
    :param output_width: Width of the output video
    :param output_height: Height of the output video
    :param zoom_factor: How much to zoom in by
    :param fps: Frames per second for the video
    :param audio_volume: Volume of the main audio
    :param sound_effect_path: Path to the sound effect file
    :param sound_effect_start: Start time of the sound effect
    :param sound_effect_end: End time of the sound effect
    :param sound_effect_volume: Volume of the sound effect
    :param zoom_to: Direction of zoom ("top", "bottom", or "center")
    :return: Path to the output video file
    """
    # Check if input is video by file extension
    is_video = input_path.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.webm'))

    # Handle video input
    if is_video:
        input_clip = VideoFileClip(input_path)
        original_duration = input_clip.duration
        img = input_clip
    else:
        # Load and prepare the image
        img_array = cv2.imread(input_path)
        img_array = cv2.cvtColor(img_array, cv2.COLOR_BGR2RGB)
        img = ImageClip(img_array)
        original_duration = None

    # Validate duration requirements
    if not is_video and duration is None and audio_path is None:
        raise ValueError("For image input, either duration or audio_path must be provided")

    if zoom_to not in ["top", "bottom", "center"]:
        raise ValueError("zoom_to must be either 'top', 'bottom', or 'center'")

    # Determine video duration and prepare audio
    if audio_path:
        audio_clip = AudioFileClip(audio_path).volumex(audio_volume)
        total_duration = audio_clip.duration
    else:
        total_duration = original_duration if is_video else duration
        audio_clip = None if not is_video else input_clip.audio

    # Handle sound effect
    if sound_effect_path:
        sound_effect_clip = AudioFileClip(sound_effect_path).volumex(sound_effect_volume)
        if sound_effect_end is None or sound_effect_end > total_duration:
            sound_effect_end = total_duration
        sound_effect_clip = sound_effect_clip.subclip(0, sound_effect_end - sound_effect_start)
        sound_effect_clip = sound_effect_clip.set_start(sound_effect_start)
        if audio_clip:
            audio_clip = CompositeAudioClip([audio_clip, sound_effect_clip])
        else:
            audio_clip = sound_effect_clip

    # Set output dimensions
    if output_width is None or output_height is None:
        output_width = img.w
        output_height = img.h

    # Calculate the target size maintaining aspect ratio
    img_ratio = img.w / img.h
    output_ratio = output_width / output_height

    # Initial scaling
    if img_ratio > output_ratio:
        new_h = output_height
        new_w = int(new_h * img_ratio)
    else:
        new_w = output_width
        new_h = int(new_w / img_ratio)

    def smooth_start_easing(t):
        """
        Linear-bezier blend for immediate start with smoothness
        """
        # Start with linear interpolation to ensure immediate movement
        linear = t
        # Blend with smooth bezier
        bezier = t * t * (3 - 2 * t)
        # Use more linear at start, more bezier towards end
        blend_factor = t * t  # Quadratic blend
        return linear * (1 - blend_factor) + bezier * blend_factor

    def get_transform_params(t):
        """
        Calculate transformation parameters with high precision
        """
        progress = smooth_start_easing(t / total_duration)

        # Calculate zoom with higher precision
        current_scale = 1.0 + (zoom_factor - 1.0) * progress

        # Calculate dimensions with preserved precision
        current_w = new_w * current_scale
        current_h = new_h * current_scale

        # Calculate offsets
        x_offset = (output_width - current_w) / 2

        if zoom_to == "center":
            # When zooming to center, maintain center position
            y_offset = (output_height - current_h) / 2
        elif zoom_to == "top":
            # When zooming to top, start at bottom and move up
            y_offset = output_height - current_h + (current_h - output_height) * progress
        else:  # bottom
            # When zooming to bottom, start at top and move down
            y_offset = -(current_h - output_height) * progress

        return current_scale, x_offset, y_offset

    def make_frame(t):
        """
        Generate frame with improved precision and interpolation
        """
        # Get the base frame (either from video or image)
        if is_video:
            base_frame = img.get_frame(t)
        else:
            base_frame = np.array(img.get_frame(0))

        # Resize the frame if needed
        if base_frame.shape[1] != new_w or base_frame.shape[0] != new_h:
            base_frame = cv2.resize(base_frame, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)

        scale, x_offset, y_offset = get_transform_params(t)
        M = np.array([
            [scale, 0, x_offset],
            [0, scale, y_offset]
        ], dtype=np.float64)

        frame = cv2.warpAffine(
            base_frame,
            M,
            (output_width, output_height),
            flags=cv2.INTER_LANCZOS4,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=(0, 0, 0)
        )

        return frame

    # Create and write video
    video_clip = VideoClip(make_frame, duration=total_duration)
    if audio_clip:
        video_clip = video_clip.set_audio(audio_clip)
    video_clip = video_clip.set_fps(fps)

    video_clip.write_videofile(
        output_video,
        codec="libx264",
        audio_codec="aac",
        fps=fps,
        temp_audiofile=f"/tmp/temp_audio_zoom_in_{str(uuid4())}.mp4",
        ffmpeg_params=[
            "-profile:v", "high",
            "-level", "4.2",
            "-pix_fmt", "yuv420p",
            "-movflags", "+faststart",
            "-x264-params", "keyint=2*fps:min-keyint=2*fps:scenecut=0"
        ]
    )

    # Clean up
    if is_video:
        input_clip.close()
    if audio_path:
        audio_clip.close()

    if not os.path.exists(output_video):
        raise FileNotFoundError(f"Output video file {output_video} not found!")

    return output_video
